from django.shortcuts import render, get_object_or_404
from django.http import Http404

TRANSACTIONS = [
    # СЕГОДНЯ (day_offset = 0)
    {
        'id': 1, 'day_offset': 0, 'time': 'minus_5',
        'title': 'SARRC_1', 'category': 'Коммунальные услуги',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'sarrc', 'comment': None
    },
   
    # ВЧЕРА (day_offset = 1)
    {
        'id': 2, 'day_offset': 1, 'time': '19:42',
        'title': 'Вкусно — и точка', 'category': 'Фастфуд',
        'amount': '−438 ₽', 'raw_amount': '438 ₽', 'is_income': False, 'pending': False,
        'logo': 'vkusno', 'comment': None
    },
    {
        'id': 3, 'day_offset': 1, 'time': '16:15',
        'title': 'SARRC_1', 'category': 'Коммунальные услуги',
        'amount': '−30 ₽', 'raw_amount': '30 ₽', 'is_income': False, 'pending': False,
        'logo': 'sarrc', 'comment': None
    },
    {
        'id': 4, 'day_offset': 1, 'time': '14:20',
        'title': 'Екатерина Б.', 'category': 'Переводы · Альфа-Банк',
        'amount': '−1 000 ₽', 'raw_amount': '1 000 ₽', 'is_income': False, 'pending': False,
        'logo': 'alfa', 'comment': 'Перевод денежных средств'
    },
    {
        'id': 5, 'day_offset': 1, 'time': '11:05',
        'title': 'SARRC_1', 'category': 'Коммунальные услуги',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'sarrc', 'comment': None
    },
    # 2 ДНЯ НАЗАД (15 октября на видео)
    {
        'id': 6, 'day_offset': 2, 'time': '20:14',
        'title': "Rostic's", 'category': 'Фастфуд',
        'amount': '−575 ₽', 'raw_amount': '575 ₽', 'is_income': False, 'pending': True,
        'logo': 'rostics', 'comment': None
    },
    # 3 ДНЯ НАЗАД (14 октября на видео)
    {
        'id': 7, 'day_offset': 3, 'time': '18:30',
        'title': 'Burger King', 'category': 'Фастфуд',
        'amount': '−31,99 ₽', 'raw_amount': '31,99 ₽', 'is_income': False, 'pending': False,
        'logo': 'bk', 'comment': None
    },
    {
        'id': 8, 'day_offset': 3, 'time': '13:10',
        'title': 'Сервисы Яндекса', 'category': 'Цифровые товары',
        'amount': '−100 ₽', 'raw_amount': '100 ₽', 'is_income': False, 'pending': False,
        'logo': 'yandex', 'comment': None
    },
    {
        'id': 9, 'day_offset': 3, 'time': '08:22',
        'title': 'Транспорт Саратова', 'category': 'Транспорт',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'saratov', 'comment': None
    },
    # 4 ДНЯ НАЗАД (13 октября на видео)
    {
        'id': 10, 'day_offset': 4, 'time': '21:05',
        'title': 'Burger King', 'category': 'Фастфуд',
        'amount': '−804,98 ₽', 'raw_amount': '804,98 ₽', 'is_income': False, 'pending': False,
        'logo': 'bk', 'comment': None
    },
    # 5 ДНЕЙ НАЗАД (12 октября на видео)
    {
        'id': 11, 'day_offset': 5, 'time': '20:45',
        'title': 'Красное&Белое', 'category': 'Продукты',
        'amount': '−115,98 ₽', 'raw_amount': '115,98 ₽', 'is_income': False, 'pending': False,
        'logo': 'kb', 'comment': None
    },
    {
        'id': 12, 'day_offset': 5, 'time': '16:12',
        'title': "Rostic's", 'category': 'Фастфуд',
        'amount': '−300 ₽', 'raw_amount': '300 ₽', 'is_income': False, 'pending': False,
        'logo': 'rostics', 'comment': None
    },
    {
        'id': 13, 'day_offset': 5, 'time': '12:40',
        'title': 'Транспорт Саратова', 'category': 'Транспорт',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'saratov', 'comment': None
    },
    {
        'id': 14, 'day_offset': 5, 'time': '09:50',
        'title': 'Красное&Белое', 'category': 'Продукты',
        'amount': '−59,99 ₽', 'raw_amount': '59,99 ₽', 'is_income': False, 'pending': False,
        'logo': 'kb', 'comment': None
    },
    # 6 ДНЕЙ НАЗАД (11 октября на видео)
    {
        'id': 15, 'day_offset': 6, 'time': '17:33',
        'title': 'Пятёрочка', 'category': 'Продукты',
        'amount': '−194,99 ₽', 'raw_amount': '194,99 ₽', 'is_income': False, 'pending': False,
        'logo': 'pyaterochka', 'comment': None
    },
    # 7 ДНЕЙ НАЗАД (10 октября на видео)
    {
        'id': 16, 'day_offset': 7, 'time': '22:18',
        'title': 'Яндекс.Такси', 'category': 'Такси',
        'amount': '−505 ₽', 'raw_amount': '505 ₽', 'is_income': False, 'pending': False,
        'logo': 'go', 'comment': None
    },
    {
        'id': 17, 'day_offset': 7, 'time': '18:04',
        'title': 'Сергей Е.', 'category': 'Переводы · СБП · Т-Банк',
        'amount': '−1 500 ₽', 'raw_amount': '1 500 ₽', 'is_income': False, 'pending': False,
        'logo': 'tbank', 'comment': 'Перевод денежных средств'
    },
    {
        'id': 18, 'day_offset': 7, 'time': '15:11',
        'title': 'Сбербанк', 'category': 'Пополнения',
        'amount': '+2 000 ₽', 'raw_amount': '2 000 ₽', 'is_income': True, 'pending': False,
        'logo': 'sber_in', 'comment': None
    },
    {
        'id': 19, 'day_offset': 7, 'time': '15:11',
        'title': 'Комиссия за внесение нал...', 'category': 'Финансовые операции',
        'amount': '−30 ₽', 'raw_amount': '30 ₽', 'is_income': False, 'pending': False,
        'logo': 'commission', 'comment': None
    },
    {
        'id': 20, 'day_offset': 7, 'time': '13:45',
        'title': 'Вкусно — и точка', 'category': 'Фастфуд',
        'amount': '−700 ₽', 'raw_amount': '700 ₽', 'is_income': False, 'pending': False,
        'logo': 'vkusno', 'comment': None
    },
    {
        'id': 21, 'day_offset': 7, 'time': '09:10',
        'title': 'Яндекс.Такси', 'category': 'Такси',
        'amount': '−343 ₽', 'raw_amount': '343 ₽', 'is_income': False, 'pending': False,
        'logo': 'go', 'comment': None
    },
    # 8 ДНЕЙ НАЗАД (9 октября на видео)
    {
        'id': 22, 'day_offset': 8, 'time': '20:02',
        'title': 'Красное&Белое', 'category': 'Продукты',
        'amount': '−69,69 ₽', 'raw_amount': '69,69 ₽', 'is_income': False, 'pending': False,
        'logo': 'kb', 'comment': None
    },
    {
        'id': 23, 'day_offset': 8, 'time': '17:25',
        'title': 'Burger King', 'category': 'Фастфуд',
        'amount': '−574,96 ₽', 'raw_amount': '574,96 ₽', 'is_income': False, 'pending': False,
        'logo': 'bk', 'comment': None
    },
    {
        'id': 24, 'day_offset': 8, 'time': '14:19',
        'title': 'Транспорт Саратова', 'category': 'Транспорт',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'saratov', 'comment': None
    },
    {
        'id': 25, 'day_offset': 8, 'time': '11:40',
        'title': 'Магнит', 'category': 'Продукты',
        'amount': '−43,99 ₽', 'raw_amount': '43,99 ₽', 'is_income': False, 'pending': False,
        'logo': 'magnit', 'comment': None
    },
    {
        'id': 26, 'day_offset': 8, 'time': '01:05',
        'title': 'SG Premium', 'category': 'Цифровые товары',
        'amount': '−299 ₽', 'raw_amount': '299 ₽', 'is_income': False, 'pending': False,
        'logo': 'sg', 'comment': None
    },
    # 9 ДНЕЙ НАЗАД (8 октября на видео)
    {
        'id': 27, 'day_offset': 9, 'time': '21:50',
        'title': 'Игромагаз', 'category': 'Цифровые товары',
        'amount': '−1 369,35 ₽', 'raw_amount': '1 369,35 ₽', 'is_income': False, 'pending': False,
        'logo': 'igromagaz', 'comment': None
    },
    {
        'id': 28, 'day_offset': 9, 'time': '19:15',
        'title': 'Вкусно — и точка', 'category': 'Фастфуд',
        'amount': '−852 ₽', 'raw_amount': '852 ₽', 'is_income': False, 'pending': False,
        'logo': 'vkusno', 'comment': None
    },
    {
        'id': 29, 'day_offset': 9, 'time': '18:10',
        'title': 'Александр Е.', 'category': 'Переводы · СБП · Кредит Европа Банк (...',
        'amount': '+852 ₽', 'raw_amount': '852 ₽', 'is_income': True, 'pending': False,
        'logo': 'ceb_sbp', 'comment': None
    },
    {
        'id': 30, 'day_offset': 9, 'time': '16:40',
        'title': 'Пятёрочка', 'category': 'Продукты',
        'amount': '−89,99 ₽', 'raw_amount': '89,99 ₽', 'is_income': False, 'pending': False,
        'logo': 'pyaterochka', 'comment': None
    },
    {
        'id': 31, 'day_offset': 9, 'time': '15:20',
        'title': 'Красное&Белое', 'category': 'Продукты',
        'amount': '−89,69 ₽', 'raw_amount': '89,69 ₽', 'is_income': False, 'pending': False,
        'logo': 'kb', 'comment': None
    },
    {
        'id': 32, 'day_offset': 9, 'time': '15:18',
        'title': 'Красное&Белое', 'category': 'Продукты',
        'amount': '−220 ₽', 'raw_amount': '220 ₽', 'is_income': False, 'pending': False,
        'logo': 'kb', 'comment': None
    },
    {
        'id': 33, 'day_offset': 9, 'time': '13:12',
        'title': 'Вкусно — и точка', 'category': 'Фастфуд',
        'amount': '−767 ₽', 'raw_amount': '767 ₽', 'is_income': False, 'pending': False,
        'logo': 'vkusno', 'comment': None
    },
    {
        'id': 34, 'day_offset': 9, 'time': '11:30',
        'title': 'Егор Р.', 'category': 'Переводы · СБП · Сбербанк',
        'amount': '−6 534,70 ₽', 'raw_amount': '6 534,70 ₽', 'is_income': False, 'pending': False,
        'logo': 'sber_sbp', 'comment': 'Денежный перевод денежный перевод егор (отчетоность)'
    },
    {
        'id': 35, 'day_offset': 9, 'time': '08:30',
        'title': 'Транспорт Саратова', 'category': 'Транспорт',
        'amount': '−37 ₽', 'raw_amount': '37 ₽', 'is_income': False, 'pending': False,
        'logo': 'saratov', 'comment': None
    },
    {
        'id': 36, 'day_offset': 9, 'time': '08:05',
        'title': 'РЖД', 'category': 'Пополнения',
        'amount': '+150 ₽', 'raw_amount': '150 ₽', 'is_income': True, 'pending': False,
        'logo': 'rzd', 'comment': None
    },
    {
        'id': 37, 'day_offset': 9, 'time': '08:04',
        'title': 'РЖД', 'category': 'Пополнения',
        'amount': '+150 ₽', 'raw_amount': '150 ₽', 'is_income': True, 'pending': False,
        'logo': 'rzd', 'comment': None
    },
    {
        'id': 38, 'day_offset': 9, 'time': '08:00',
        'title': 'РЖД', 'category': 'Пополнения',
        'amount': '+6 384,70 ₽', 'raw_amount': '6 384,70 ₽', 'is_income': True, 'pending': False,
        'logo': 'rzd', 'comment': None
    },
]


def main(request):
    return render(request, 'core/home.html')


def payments(request):
    return render(request, 'core/payments.html')


def benefits(request):
    return render(request, 'core/benefits.html')


def history(request):
    # Группируем операции по day_offset для вывода по дням
    grouped = {}
    for tx in TRANSACTIONS:
        offset = tx['day_offset']
        if offset not in grouped:
            grouped[offset] = []
        grouped[offset].append(tx)

    days = [{'day_offset': k, 'items': v} for k, v in grouped.items()]
    return render(request, 'core/history.html', {'days': days})


import random

def receipt_view(request, tx_id):
    tx = next((item for item in TRANSACTIONS if item['id'] == tx_id), None)
    if not tx:
        raise Http404("Операция не найдена")
    return render(request, 'core/receipt.html', {'tx': tx})

def build_tx_details(tx):
    # Детерминированный рандом от id операции, чтобы цифры были уникальными, но не прыгали при перезагрузке
    rng = random.Random(tx['id'] * 98765)
    rand_digits = lambda n: ''.join(str(rng.randint(0, 9)) for _ in range(n))

    # 1. Точные данные для SARRC_1 со скриншота
    # 1. Точные данные для SARRC_1 со скриншота
    if tx['logo'] == 'sarrc':
        return {
            'show_card_icon': False,
            'rows': [
                {'label': 'Наименование ТСП', 'value': 'SARRC_1'},
                {'label': 'Счёт списания', 'value': 'Текущий счёт ··2395'},
                {'label': 'Идентификатор платежа', 'value': 'A62900812177221K0B10070011870702'},
                {'label': 'Банк получателя', 'value': 'Промсвязьбанк'},
                {'label': 'Получатель', 'value': 'ООО "САРРЦ"'},
                {'label': 'Детали платежа', 'value': 'Оплата по QR через СБП'},
                {'label': 'Назначение платежа', 'value': 'Оплата заказа'},
            ]
        }

    # 2. Переводы людям (СБП и внутри Альфа-Банка)
    if tx['logo'] in ('alfa', 'tbank', 'sber_sbp', 'ceb_sbp'):
        banks = {
            'alfa': 'Альфа-Банк',
            'tbank': 'Т-Банк',
            'sber_sbp': 'Сбербанк',
            'ceb_sbp': 'Кредит Европа Банк',
        }
        sbp_id = f"B6290{rand_digits(10)}K0B100{rand_digits(11)}"
        phone = f"+7 (9{rand_digits(2)}) ***-**-{rand_digits(2)}"
        account_label = 'Счёт зачисления' if tx['is_income'] else 'Счёт списания'
        person_label = 'Отправитель' if tx['is_income'] else 'Получатель'

        rows = [
            {'label': account_label, 'value': 'Текущий счёт ··2395'},
            {'label': person_label, 'value': tx['title']},
            {'label': 'Номер телефона', 'value': phone},
            {'label': 'Банк получателя' if not tx['is_income'] else 'Банк отправителя', 'value': banks[tx['logo']]},
            {'label': 'Идентификатор операции СБП', 'value': sbp_id},
            {'label': 'Способ перевода', 'value': 'Система быстрых платежей (СБП)' if tx['logo'] != 'alfa' else 'Перевод клиенту Альфа-Банка'},
        ]
        if tx.get('comment'):
            rows.append({'label': 'Сообщение', 'value': tx['comment']})

        return {'show_card_icon': False, 'rows': rows}

    # 3. Пополнения (РЖД, Сбербанк)
    if tx['is_income']:
        return {
            'show_card_icon': False,
            'rows': [
                {'label': 'Счёт зачисления', 'value': 'Текущий счёт ··2395'},
                {'label': 'Отправитель', 'value': 'ОАО "РЖД"' if tx['logo'] == 'rzd' else tx['title']},
                {'label': 'Идентификатор операции', 'value': f"C62900{rand_digits(18)}"},
                {'label': 'Тип операции', 'value': 'Зачисление средств'},
                {'label': 'Назначение платежа', 'value': 'Возврат / Пополнение по операции'},
            ]
        }

    # 4. Комиссия
    if tx['logo'] == 'commission':
        return {
            'show_card_icon': False,
            'rows': [
                {'label': 'Счёт списания', 'value': 'Текущий счёт ··2395'},
                {'label': 'Номер документа', 'value': rand_digits(10)},
                {'label': 'Основание', 'value': 'Комиссия по тарифам банка'},
            ]
        }

    # 5. Оплата картой в магазинах, транспорте и сервисах
    mcc_map = {
        'Транспорт': '4111 (Пассажирские перевозки)',
        'Фастфуд': '5814 (Фастфуд)',
        'Продукты': '5411 (Бакалейные магазины, супермаркеты)',
        'Такси': '4121 (Такси и лимузины)',
        'Цифровые товары': '5815 (Цифровые товары)',
    }
    legal_names = {
        'saratov': 'МУПП "Саратовгорэлектротранс"',
        'vkusno': 'ООО "Система ПБО"',
        'rostics': 'ООО "Юнирест"',
        'bk': 'ООО "Бургер Рус"',
        'kb': 'ООО "Альфа-М"',
        'pyaterochka': 'ООО "Агроторг"',
        'magnit': 'АО "Тандер"',
        'go': 'ООО "Яндекс.Такси"',
        'yandex': 'ООО "Яндекс Плюс"',
        'sg': 'SG PREMIUM STORE',
        'igromagaz': 'ООО "Игромагаз"',
    }

    return {
        'show_card_icon': True,  # Показываем красную иконку карты списания сверху
        'rows': [
            {'label': 'Счёт списания', 'value': 'Текущий счёт ··2395'},
            {'label': 'Наименование ТСП', 'value': tx['title']},
            {'label': 'Юридическое лицо', 'value': legal_names.get(tx['logo'], tx['title'])},
            {'label': 'Код авторизации', 'value': rand_digits(6)},
            {'label': 'Номер терминала', 'value': f"TID{rand_digits(8)}"},
            {'label': 'MCC-код', 'value': mcc_map.get(tx['category'], '5999 (Различные магазины)')},
            {'label': 'Способ оплаты', 'value': 'Карта МИР ··4781'},
        ]
    }


def transaction_detail(request, tx_id):
    tx = next((item for item in TRANSACTIONS if item['id'] == tx_id), None)
    if not tx:
        raise Http404("Операция не найдена")
    details = build_tx_details(tx)
    return render(request, 'core/transaction_detail.html', {'tx': tx, 'details': details})