from django.urls import path
from .views import *

urlpatterns = [
    path('', main, name = 'home'),
    path('payments/', payments, name='payments'),
    path('benefits/', benefits, name='benefits'),
    path('history/', history, name = 'history'),
    path('history/transaction/<int:tx_id>/', transaction_detail, name = 'transaction_detail'),
    path('history/transaction/<int:tx_id>/receipt/', receipt_view, name='receipt'),
]