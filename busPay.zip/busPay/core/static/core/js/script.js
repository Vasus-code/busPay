document.addEventListener('DOMContentLoaded', () => {
    const now = new Date();
    const txMinus5 = new Date(now.getTime() - 5 * 60 * 1000);

    const monthsGenitive = [
        'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
        'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
    ];
    const monthsPrepositional = [
        'январе', 'феврале', 'марте', 'апреле', 'мае', 'июне',
        'июле', 'августе', 'сентябре', 'октябре', 'ноябре', 'декабре'
    ];
    const monthsAccusative = [
        'январь', 'февраль', 'март', 'апрель', 'май', 'июнь',
        'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'
    ];

    const padZero = (num) => String(num).padStart(2, '0');

    // 1. Все заголовки дней в Истории (СЕГОДНЯ, ВЧЕРА и предыдущие дни)
    document.querySelectorAll('.js-dynamic-date').forEach(el => {
        const offset = parseInt(el.dataset.offset || '0', 10);
        const d = new Date(now);
        d.setDate(now.getDate() - offset);

        const dayNum = d.getDate();
        const monthName = monthsGenitive[d.getMonth()].toUpperCase();

        if (offset === 0) {
            const dToday = txMinus5.getDate();
            const mToday = monthsGenitive[txMinus5.getMonth()].toUpperCase();
            el.textContent = `СЕГОДНЯ, ${dToday} ${mToday}`;
        } else if (offset === 1) {
            el.textContent = `ВЧЕРА, ${dayNum} ${monthName}`;
        } else {
            el.textContent = `${dayNum} ${monthName}`;
        }
    });

    // 2. "Расходы в <месяце>"
    const monthExpenses = document.getElementById('js-month-expenses');
    if (monthExpenses) {
        monthExpenses.textContent = `Расходы в ${monthsPrepositional[now.getMonth()]}`;
    }

    // 3. Месяц в винительном падеже ("за октябрь" / "На октябрь")
    document.querySelectorAll('.js-acc-month').forEach(el => {
        el.textContent = monthsAccusative[now.getMonth()];
    });

    // 4. Дата и время в деталях любой операции
    const txDatetime = document.getElementById('js-tx-datetime');
    if (txDatetime) {
        const offset = parseInt(txDatetime.dataset.offset || '0', 10);
        const timeAttr = txDatetime.dataset.time;

        if (timeAttr === 'minus_5') {
            const day = txMinus5.getDate();
            const month = monthsGenitive[txMinus5.getMonth()];
            const hours = padZero(txMinus5.getHours());
            const minutes = padZero(txMinus5.getMinutes());
            txDatetime.textContent = `${day} ${month}, ${hours}:${minutes}`;
        } else {
            const d = new Date(now);
            d.setDate(now.getDate() - offset);
            const day = d.getDate();
            const month = monthsGenitive[d.getMonth()];
            txDatetime.textContent = `${day} ${month}, ${timeAttr}`;
        }
    }

    // 5. Тумблер "Учитывать в аналитике" (интерактивное переключение)
    const toggle = document.getElementById('js-analytics-toggle');
    if (toggle) {
        toggle.addEventListener('click', () => {
            toggle.classList.toggle('active');
            toggle.style.backgroundColor = toggle.classList.contains('active') ? '#32d74b' : '#39393d';
            toggle.style.justifyContent = toggle.classList.contains('active') ? 'flex-end' : 'flex-start';
        });
    }
});

// Генерация дат квитанции по МСК (-5 минут для отправки, текущее для формирования)
    const txTimeEl = document.getElementById('js-tx-time');
    const genTimeEl = document.getElementById('js-gen-time');

    if (txTimeEl || genTimeEl) {
        // Получаем время устройства в формате МСК (UTC+3)
        const nowMsk = new Date(new Date().toLocaleString("en-US", {timeZone: "Europe/Moscow"}));
        const txMsk = new Date(nowMsk.getTime() - 5 * 60 * 1000);

        const pad = (n) => String(n).padStart(2, '0');
        const formatDate = (d) => `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())} мск`;
        const formatGen = (d) => `Сформирована<br>${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())} мск`;

        if (txTimeEl) txTimeEl.textContent = formatDate(txMsk);
        if (genTimeEl) genTimeEl.innerHTML = formatGen(nowMsk);
    }